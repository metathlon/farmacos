<?php
$titulo = "Farmacos";

$mysql_bd_hostname = "localhost";
$mysql_bd_user = "farmacos";
$mysql_bd_password = "alcachofas14109";
$mysql_bd_database = "farmacos";
?>