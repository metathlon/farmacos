<?
$connect = mysql_connect($servidor,$usuario,$clave);
mysql_select_db($basedatos,$connect);
?>